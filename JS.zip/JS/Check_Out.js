document.addEventListener("DOMContentLoaded", () => {
    renderCheckoutSummary();
    // Ensure cart UI is also updated on checkout page load
    if (typeof updateCartUI === 'function') {
        updateCartUI(); // Call from Shop.js
    }
});

const TAX_RATE = 0.10; // 10% tax
const DELIVERY_CHARGE = 250; // Fixed delivery charge

function renderCheckoutSummary() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const checkoutCartItemsDiv = document.getElementById('checkout-cart-items');
    const subtotalAmountSpan = document.getElementById('subtotal-amount');
    const taxAmountSpan = document.getElementById('tax-amount');
    const deliveryAmountSpan = document.getElementById('delivery-amount');
    const totalAmountSpan = document.getElementById('total-amount');
    const placeOrderBtn = document.querySelector('.place-order-btn');
    const emptyCartMessage = document.querySelector('.empty-cart-message');

    checkoutCartItemsDiv.innerHTML = ''; // Clear previous content
    let subtotal = 0;

    if (cart.length === 0) {
        emptyCartMessage.style.display = 'block'; // Show empty cart message
        placeOrderBtn.disabled = true; // Disable place order button
    } else {
        emptyCartMessage.style.display = 'none'; // Hide empty cart message
        placeOrderBtn.disabled = false; // Enable place order button

        cart.forEach(item => {
            const itemPrice = item.price * (item.quantity || 1);
            subtotal += itemPrice;
            const itemDiv = document.createElement('div');
            itemDiv.className = 'cart-item-checkout';
            itemDiv.innerHTML = `
                <img src="${item.images && item.images.length > 0 ? item.images[0] : '../Images/fallback.jpg'}" alt="${item.name}">
                <div class="item-details">
                    <span class="item-name">${item.name}</span>
                    <span class="item-options">${item.selectedSize ? item.selectedSize : ''}${item.selectedColor ? `, ${item.selectedColor}` : ''} x ${item.quantity || 1}</span>
                    <span class="item-price">Rs ${itemPrice.toFixed(2)}</span>
                </div>
            `;
            checkoutCartItemsDiv.appendChild(itemDiv);
        });
    }

    const tax = subtotal * TAX_RATE;
    const delivery = cart.length > 0 ? DELIVERY_CHARGE : 0; // Only charge delivery if there are items
    const total = subtotal + tax + delivery;

    subtotalAmountSpan.textContent = `Rs ${subtotal.toFixed(2)}`;
    taxAmountSpan.textContent = `Rs ${tax.toFixed(2)}`;
    deliveryAmountSpan.textContent = `Rs ${delivery.toFixed(2)}`;
    totalAmountSpan.textContent = `Rs ${total.toFixed(2)}`;
}

function placeOrder() {
    const feedbackElement = document.getElementById('order-feedback');
    const placeOrderBtn = document.querySelector('.place-order-btn');

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length === 0) {
        feedbackElement.textContent = "Your cart is empty. Please add items before placing an order.";
        feedbackElement.style.color = 'red';
        return;
    }

    // Disable button to prevent multiple clicks
    placeOrderBtn.disabled = true;
    placeOrderBtn.textContent = "Processing...";

    // Simulate an order processing delay
    setTimeout(() => {
        localStorage.removeItem('cart'); // Clear the cart
        // Also update cart UI from Shop.js if it's loaded
        if (typeof updateCartUI === 'function') {
            updateCartUI();
        }
        feedbackElement.textContent = "Order placed successfully! Thank you for your purchase.";
        feedbackElement.style.color = '#ffd700'; // Yellow success message

        // Optionally redirect to a thank you page or home page after a short delay
        setTimeout(() => {
            window.location.href = "Home_Page.html";
        }, 3000); // Redirect after 3 seconds
    }, 1500); // Simulate 1.5 seconds processing
}

