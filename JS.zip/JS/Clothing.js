document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('neural-bg');
  const ctx = canvas.getContext('2d');

  let width, height;
  function resizeCanvas() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  const neurons = [];
  const maxNeurons = 60;
  const connectionDistance = 160;

  for (let i = 0; i < maxNeurons; i++) {
    neurons.push({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.8,
      vy: (Math.random() - 0.5) * 0.8,
      radius: 2 + Math.random() * 2
    });
  }

  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < neurons.length; i++) {
      const n1 = neurons[i];
      for (let j = i + 1; j < neurons.length; j++) {
        const n2 = neurons[j];
        const dx = n1.x - n2.x;
        const dy = n1.y - n2.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < connectionDistance) {
          const opacity = 1 - dist / connectionDistance;
          ctx.strokeStyle = `rgba(255, 215, 0, ${opacity})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(n1.x, n1.y);
          ctx.lineTo(n2.x, n2.y);
          ctx.stroke();
        }
      }
    }

    for (const n of neurons) {
      ctx.beginPath();
      const gradient = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.radius * 4);
      gradient.addColorStop(0, 'rgba(255, 215, 0, 0.9)');
      gradient.addColorStop(1, 'rgba(255, 215, 0, 0)');
      ctx.fillStyle = gradient;
      ctx.arc(n.x, n.y, n.radius * 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.fillStyle = '#ffd700';
      ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
      ctx.fill();
    }

    for (const n of neurons) {
      n.x += n.vx;
      n.y += n.vy;

      if (n.x < 0 || n.x > width) n.vx *= -1;
      if (n.y < 0 || n.y > height) n.vy *= -1;
    }

    requestAnimationFrame(animate);
  }

  animate();

  let user = null;

function showSection(id) {
  const sections = document.querySelectorAll('.section');
  sections.forEach(sec => sec.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

// Simulated Google login
function googleLogin() {
  user = {
    name: "Asjal Abdullah",
    address: "Street 25, Karachi",
    phone: "0300-1234567",
    orders: ["Tribe Tee - White", "Drop Shoulder Black"],
    wishlist: ["Vintage Blue Tee", "Sunset Hoodie"]
  };
  showProfile();
}

// Manual login
function login() {
  const name = document.getElementById("username").value;
  const address = document.getElementById("address").value;
  const phone = document.getElementById("phone").value;

  if (!name || !address || !phone) {
    alert("Please fill all fields.");
    return;
  }

  user = { name, address, phone, orders: [], wishlist: [] };
  showProfile();
}

function showProfile() {
  document.getElementById("auth-area").style.display = "none";
  document.getElementById("profile-info").style.display = "block";
  document.getElementById("user-name").textContent = user.name;
  document.getElementById("user-address").textContent = user.address;
  document.getElementById("user-phone").textContent = user.phone;

  // Populate orders
  const past = document.getElementById("past-orders");
  past.innerHTML = "";
  if (user.orders.length > 0) {
    user.orders.forEach(order => {
      const li = document.createElement("li");
      li.textContent = order;
      past.appendChild(li);
    });
  } else {
    past.innerHTML = "<li>No past orders found.</li>";
  }

  // Populate wishlist
  const wish = document.getElementById("wishlist-items");
  wish.innerHTML = "";
  if (user.wishlist.length > 0) {
    user.wishlist.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      wish.appendChild(li);
    });
  } else {
    wish.innerHTML = "<li>No items in wishlist.</li>";
  }
}

function logout() {
  user = null;
  document.getElementById("auth-area").style.display = "block";
  document.getElementById("profile-info").style.display = "none";
  document.getElementById("past-orders").innerHTML = "";
  document.getElementById("wishlist-items").innerHTML = "";
  alert("You have been logged out.");
}

});

function showSection(id) {
  document.querySelectorAll('.section').forEach(section => {
    section.style.display = 'none';
  });
  document.getElementById(id).style.display = 'block';
}

function login() {
  const name = document.getElementById('username').value;
  const address = document.getElementById('address').value;
  const phone = document.getElementById('phone').value;

  document.getElementById('user-name').textContent = name;
  document.getElementById('user-address').textContent = address;
  document.getElementById('user-phone').textContent = phone;

  document.getElementById('auth-area').style.display = 'none';
  document.getElementById('profile-info').style.display = 'block';
}

function logout() {
  document.getElementById('auth-area').style.display = 'block';
  document.getElementById('profile-info').style.display = 'none';
  document.getElementById('edit-profile-area').style.display = 'none';
}

function showEditProfile() {
  document.getElementById('edit-profile-area').style.display = 'block';
}

function saveProfile() {
  const name = document.getElementById('edit-username').value;
  const address = document.getElementById('edit-address').value;
  const phone = document.getElementById('edit-phone').value;

  document.getElementById('user-name').textContent = name;
  document.getElementById('user-address').textContent = address;
  document.getElementById('user-phone').textContent = phone;

  document.getElementById('edit-profile-area').style.display = 'none';
}

function cancelEditProfile() {
  document.getElementById('edit-profile-area').style.display = 'none';
}

function googleLogin() {
  alert("Google Login will be integrated soon.");
}