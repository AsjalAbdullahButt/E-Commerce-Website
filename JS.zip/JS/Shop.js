// --- Product Data ---
const productsData = [
    {
        id: 'Shirt_01.jpg',
        name: 'Plain Black',
        price:  1999.00 ,
        description: 'Embrace the shadows with our Dark Knight Tee. Made from premium, soft cotton, this drop-shoulder t-shirt offers an oversized fit for ultimate comfort and street-ready style. Features a subtle, high-quality print inspired by urban nights.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_01.jpg',
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_01_1.jpg',
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_01_2.jpg'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'Black', hex: '#000000' },{name: 'White',hex:'White'}]
    },
    {
        id: 'Shirt_02',
        name: 'Plain Turquoise',
        price: 2199.00,
        description: 'Step into the future with Elegant Colors. Its vibrant neon accents on a dark base make a bold statement. Crafted for a relaxed fit, perfect for tech-savvy fashion enthusiasts.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_02.jpg',
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_02_1.png',
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_02_2.png'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'Black', hex: '#000000' }, { name: 'Dark Grey', hex: '#36454F' }]
    },
    {
        id: 'Shirt_03',
        name: 'Plain White',
        price: 1999.00,
        description: 'Experience unique style with the Beautiful Color. Its broken pattern design symbolizes digital artistry and rebellion. Enjoy the loose fit and soft fabric for all-day wear.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_03.jpg',
            '../Images/abstract_glitch_tee_1.jpg',
            '../Images/abstract_glitch_tee_2.jpg'
        ],
        sizes: ['Small', 'Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'White', hex: '#FFFFFF' }, { name: 'Black', hex: '#000000' }]
    },
    {
        id: 'Shirt_04',
        name: 'Black Design',
        price: 2199.00,
        description: 'The Dark Design captures the essence of a futuristic cityscape at dawn. Its striking graphic and comfortable drop-shoulder design make it a must-have for your urban wardrobe.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_04.jpg',
            '../Images/neon_horizon_tee_1.jpg',
            '../Images/neon_horizon_tee_2.jpg'
        ],
        sizes: ['Medium', 'Large'],
        colors: [{ name: 'Black', hex: '#000000' }]
    },
    {
        id: 'Shirt_05',
        name: 'Multi Color',
        price: 1999.00,
        description: 'Channel retro-futuristic vibes with the Vaporwave Sunset Tee. Featuring a gradient sunset graphic and an ultra-comfortable fit, it\'s perfect for lounging or a night out.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_05.jpg',
            '../Images/vaporwave_sunset_tee_1.jpg',
            '../Images/vaporwave_sunset_tee_2.jpg'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'White', hex: '#FFFFFF' }]
    },
    {
        id: 'Shirt_06',
        name: 'Blue Animated',
        price: 2499.00,
        description: 'Channel retro-futuristic vibes with the Vaporwave Sunset Tee. Featuring a gradient sunset graphic and an ultra-comfortable fit, it\'s perfect for lounging or a night out.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/shirt_06.jpg',
            '../Images/vaporwave_sunset_tee_1.jpg',
            '../Images/vaporwave_sunset_tee_2.jpg'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'White', hex: '#FFFFFF' }]
    },
        {
        id: 'Shirt_07',
        name: 'Orange Black Mix',
        price: 2499.00,
        description: 'Channel retro-futuristic vibes with the Vaporwave Sunset Tee. Featuring a gradient sunset graphic and an ultra-comfortable fit, it\'s perfect for lounging or a night out.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_07.jpg',
            '../Images/vaporwave_sunset_tee_1.jpg',
            '../Images/vaporwave_sunset_tee_2.jpg'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'White', hex: '#FFFFFF' }]
    },
        {
        id: 'Shirt_08',
        name: 'Plain Blue',
        price: 1999.00,
        description: 'Channel retro-futuristic vibes with the Vaporwave Sunset Tee. Featuring a gradient sunset graphic and an ultra-comfortable fit, it\'s perfect for lounging or a night out.',
        images: [
            '/home/kbk-soft/Desktop/WebSite/Images/Shirt_08.jpg',
            '../Images/vaporwave_sunset_tee_1.jpg',
            '../Images/vaporwave_sunset_tee_2.jpg'
        ],
        sizes: ['Medium', 'Large', 'Extra Large'],
        colors: [{ name: 'White', hex: '#FFFFFF' }]
    },
    {
     id : 'Shirt_09',
     name :' Royal Blue',
     price : 2499.00,
     description : 'A Classy Royal Color that reflects to your elegance ,charm  and give a descent look to your royal personality with comfortable fitting ,stitched to perfection.',
     images : [
     '/home/kbk-soft/Desktop/WebSite/Images/Shirt_09.jpg',
     '/home/kbk-soft/Desktop/WebSite/Images/Shirt_09_1.jpeg',
     '../Images/Shirt_09_2.jpeg'
     ],
     sizes : ['Medium','Large','Extra Large'],
     colors : [{name :'Royal Blue ',hex : 'Royal Blue'}]
    }
];


// --- Cart Logic ---
let cart = []; // Initialize cart array

// Load cart from localStorage on page load
document.addEventListener("DOMContentLoaded", () => {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cart = JSON.parse(storedCart);
        updateCartUI();
    }
    // Only render products if on the Shop Page
    if (document.getElementById('product-grid')) {
        renderProducts();
    }
});

function toggleCart() {
  document.getElementById('cart').classList.toggle('open');
}

// Make addToCartWithAnimation globally accessible
window.addToCartWithAnimation = function(button, product) {
  // Call the actual addToCart function first
  window.addToCart(product);

  const dot = document.createElement('div');
  dot.classList.add('flying-dot');

  const rectStart = button.getBoundingClientRect();
  const cartTarget = document.querySelector('.cart-icon-container') || document.getElementById('cart-count-top');

  if (!cartTarget) {
      console.error("Cart target not found for animation. Please ensure an element with class 'cart-icon-container' or id 'cart-count-top' exists.");
      return; // Exit if no target for animation
  }

  const rectEnd = cartTarget.getBoundingClientRect();

  // Set initial position of the dot
  dot.style.left = `${rectStart.left + rectStart.width / 2 - 7.5}px`; // 7.5px is half of dot width
  dot.style.top = `${rectStart.top + rectStart.height / 2 - 7.5}px`;

  // Calculate destination relative to the dot's initial position
  const startX = rectStart.left + rectStart.width / 2;
  const startY = rectStart.top + rectStart.height / 2;
  const endX = rectEnd.left + rectEnd.width / 2;
  const endY = rectEnd.top + rectEnd.height / 2;

  document.body.appendChild(dot);

  dot.style.setProperty('--start-x', `${0}px`);
  dot.style.setProperty('--start-y', `${0}px`);
  dot.style.setProperty('--end-x', `${endX - startX}px`);
  dot.style.setProperty('--end-y', `${endY - startY}px`);


  dot.addEventListener('animationend', () => {
      dot.remove();
      // Add a small bounce/pop to the cart icon
      const cartCountBubble = document.getElementById('cart-count-top');
      if (cartCountBubble) {
          cartCountBubble.classList.add('updated');
          cartCountBubble.addEventListener('animationend', () => {
              cartCountBubble.classList.remove('updated');
          }, { once: true });
      }
  });

  // Add a quick visual feedback to the button
  button.classList.add('clicked');
  setTimeout(() => {
      button.classList.remove('clicked');
  }, 500);
};


window.addToCart = function(productToAdd) {
    // Check if the product (same ID, size, color) already exists in cart
    const existingItemIndex = cart.findIndex(item =>
        item.id === productToAdd.id &&
        item.selectedSize === productToAdd.selectedSize &&
        item.selectedColor === productToAdd.selectedColor
    );

    if (existingItemIndex > -1) {
        // If it exists, just increment the quantity
        cart[existingItemIndex].quantity = (cart[existingItemIndex].quantity || 1) + 1;
    } else {
        // If it's a new item (or new size/color variant), add it with quantity 1
        cart.push({ ...productToAdd, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartUI();
};


function updateCartUI() {
    const cartItemsDiv = document.getElementById('cart-items');
    const cartTotalSpan = document.getElementById('cart-total');
    const cartCountTopSpan = document.getElementById('cart-count-top');
    const cartCountHeaderSpan = document.querySelector('.product-actions-top #cart-count-top'); // For product detail page cart header

    if (!cartItemsDiv || !cartTotalSpan || !cartCountTopSpan) {
        console.warn("Cart UI elements not found. Are you on the right page?");
        return;
    }

    cartItemsDiv.innerHTML = ''; // Clear previous content
    let total = 0;
    let itemCount = 0;

    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<p style="text-align: center; color: #bbb;">Your cart is empty.</p>';
    }

    cart.forEach((item, index) => {
        const itemPrice = item.price * (item.quantity || 1);
        total += itemPrice;
        itemCount += (item.quantity || 1);

        const itemDiv = document.createElement('div');
        itemDiv.className = 'cart-item';
        itemDiv.innerHTML = `
            <img src="${item.images && item.images[0] ? item.images[0] : '../Images/fallback.jpg'}" alt="${item.name}">
            <div class="item-details">
                <span class="item-name">${item.name}</span>
                <span class="item-options">${item.selectedSize ? item.selectedSize : ''}${item.selectedColor ? `, ${item.selectedColor}` : ''}</span>
                <div class="quantity-controls">
                    <button onclick="changeQuantity(${index}, -1)">-</button>
                    <span>${item.quantity || 1}</span>
                    <button onclick="changeQuantity(${index}, 1)">+</button>
                </div>
            </div>
            <span class="item-price">Rs ${(itemPrice).toFixed(2)}</span>
            <button class="remove-item" onclick="removeItem(${index})">&times;</button>
        `;
        cartItemsDiv.appendChild(itemDiv);
    });

    cartTotalSpan.textContent = total.toFixed(2);
    cartCountTopSpan.textContent = itemCount;
    if (cartCountHeaderSpan) { // Update the cart count in the product detail page header as well
        cartCountHeaderSpan.textContent = itemCount;
    }
}

window.changeQuantity = function(index, delta) {
    if (cart[index]) {
        cart[index].quantity = (cart[index].quantity || 1) + delta;
        if (cart[index].quantity <= 0) {
            removeItem(index);
        } else {
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartUI();
        }
    }
};

window.removeItem = function(index) {
    cart.splice(index, 1); // Remove 1 item at the given index
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartUI();
};

window.checkout = function() {
    if (cart.length === 0) {
        alert("Your cart is empty. Please add items before checking out.");
        return;
    }
    window.location.href = "Check_Out.html";
};


// --- Shop Page Specific Functions ---
function renderProducts() {
    const productGrid = document.getElementById('product-grid');
    if (!productGrid) return; // Exit if not on the shop page

    productGrid.innerHTML = ''; // Clear existing content

    productsData.forEach(product => {
        const productCard = document.createElement('a');
        productCard.href = `Product_Detail.html?id=${product.id}`; // Pass product ID via URL parameter
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <img src="${product.images[0]}" alt="${product.name}">
            <div class="product-card-info">
                <h3>${product.name}</h3>
                <p>Rs ${product.price.toFixed(2)}</p>
                <button class="add-to-cart-small-btn" onclick="event.preventDefault(); window.openProductDetail('${product.id}');">View Details</button>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}


// Function to pass product data to Product_Detail.html using localStorage
window.openProductDetail = function(productId) {
    const selectedProduct = productsData.find(p => p.id === productId);
    if (selectedProduct) {
        localStorage.setItem('selectedProduct', JSON.stringify(selectedProduct));
        window.location.href = 'Product_Detail.html';
    } else {
        console.error('Product not found with ID:', productId);
        alert('Product details could not be loaded.');
    }
};

// Carousel functions (if used elsewhere, e.g., for featured products)
let carouselCurrentIndex = 0;
const itemWidth = 300 + 32; // Assuming 300px width + 32px gap for a carousel item

function moveCarousel(direction) {
  const carousel = document.getElementById('carousel');
  if (!carousel) return;

  const maxIndex = carousel.children.length - 1;
  carouselCurrentIndex += direction;

  if (carouselCurrentIndex < 0) carouselCurrentIndex = 0;
  // Adjust maxIndex based on how many items are visible at once
  // This assumes 2 items are visible, so (maxIndex - (visible items - 1))
  const visibleItems = Math.floor(carousel.parentElement.clientWidth / itemWidth);
  if (carouselCurrentIndex > maxIndex - visibleItems) carouselCurrentIndex = maxIndex - visibleItems;


  const offset = -carouselCurrentIndex * itemWidth;

  carousel.style.transform = `translateX(${offset}px) perspective(1000px) rotateY(${direction * -5}deg)`;
  setTimeout(() => {
    carousel.style.transform = `translateX(${offset}px) perspective(1000px) rotateY(0deg)`;
  }, 300);
}

// Ensure the floating cart icon and cart sidebar work on all pages where Shop.js is included
document.addEventListener("DOMContentLoaded", () => {
    // Check if on a page that needs the toggleCart functionality
    const cartElement = document.getElementById('cart');
    if (cartElement) {
        const cartIconContainer = document.querySelector('.cart-icon-container');
        if (cartIconContainer) {
            cartIconContainer.addEventListener('click', (event) => {
                event.preventDefault(); // Prevent default link behavior
                toggleCart();
            });
        }
    }
    updateCartUI(); // Always update cart UI on DOM load, regardless of page
});
