document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('neural-bg');
  const ctx = canvas.getContext('2d');

  let width, height;
  function resizeCanvas() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  const neurons = [];
  // Increased maxNeurons for more density and prominence
  const maxNeurons = 80; 
  const connectionDistance = 150;

  for (let i = 0; i < maxNeurons; i++) {
    neurons.push({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.8,
      vy: (Math.random() - 0.5) * 0.8,
      radius: 2 + Math.random() * 2
    });
  }

  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < neurons.length; i++) {
      const n1 = neurons[i];
      for (let j = i + 1; j < neurons.length; j++) {
        const n2 = neurons[j];
        const dx = n1.x - n2.x;
        const dy = n1.y - n2.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < connectionDistance) {
          const opacity = 1 - dist / connectionDistance;
          // Connections are now more visible based on the gradient of the neurons
          ctx.strokeStyle = `rgba(255, 215, 0, ${opacity})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(n1.x, n1.y);
          ctx.lineTo(n2.x, n2.y);
          ctx.stroke();
        }
      }
    }

    for (const n of neurons) {
      ctx.beginPath();
      // Enhanced glow: larger radius and stronger color stops
      const glowRadiusMultiplier = 6; // You can try 8 or 10 for an even wider glow
      const gradient = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.radius * glowRadiusMultiplier);
      gradient.addColorStop(0, 'rgba(255, 215, 0, 1.0)'); // Fully opaque yellow at the center
      gradient.addColorStop(0.5, 'rgba(255, 215, 0, 0.5)'); // Stronger yellow at mid-point
      gradient.addColorStop(1, 'rgba(255, 215, 0, 0)'); // Fades to transparent
      ctx.fillStyle = gradient;
      ctx.arc(n.x, n.y, n.radius * glowRadiusMultiplier, 0, Math.PI * 2); // Match arc with gradient radius
      ctx.fill();

      // Solid yellow inner circle of the neuron
      ctx.beginPath();
      ctx.fillStyle = '#ffd700'; // Bright yellow
      ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
      ctx.fill();
    }

    // Update neuron positions
    for (const n of neurons) {
      n.x += n.vx;
      n.y += n.vy;

      // Bounce off edges
      if (n.x < 0 || n.x > width) n.vx *= -1;
      if (n.y < 0 || n.y > height) n.vy *= -1;
    }

    requestAnimationFrame(animate);
  }

  animate();
});

// Simple placeholder for canvas background (you can later add a real neural visual effect)
const canvas = document.getElementById('neural-bg');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

function drawBg() {
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}
drawBg();