let currentProduct = null;
let slideIndex = 0;
let flying = false;

document.addEventListener("DOMContentLoaded", () => {
    loadProductDetails();

    const addToCartButton = document.getElementById('add-to-cart-btn');
    if (addToCartButton) {
        addToCartButton.addEventListener('click', () => {
            if (currentProduct) {
                const selectedSize = document.getElementById('size-select').value;
                const selectedColor = document.querySelector('.color-swatch.selected')?.dataset.colorName;

                const productForCart = {
                    id: currentProduct.id,
                    name: currentProduct.name,
                    price: currentProduct.price,
                    images: currentProduct.images,
                    selectedSize,
                    selectedColor
                };

                window.addToCartWithAnimation(addToCartButton, productForCart);
                displayFeedback("Item added to cart!", "green");
            }
        });
    }

    setTimeout(() => {
        if (currentProduct && currentProduct.images.length > 0) {
            showSlides(slideIndex);
        }
    }, 100);
});

function loadProductDetails() {
    const storedProduct = localStorage.getItem('selectedProduct');
    if (storedProduct) {
        currentProduct = JSON.parse(storedProduct);
        document.getElementById('product-name').textContent = currentProduct.name;
        document.getElementById('product-price').textContent = `Rs ${currentProduct.price.toFixed(2)}`;
        document.getElementById('product-description').textContent = currentProduct.description || 'No description available.';
        document.getElementById('product-main-image').src = currentProduct.images[0] || '../Images/fallback.jpg';

        const sizeSelect = document.getElementById('size-select');
        sizeSelect.innerHTML = '';
        if (currentProduct.sizes?.length) {
            currentProduct.sizes.forEach(size => {
                const option = document.createElement('option');
                option.value = size;
                option.textContent = size;
                sizeSelect.appendChild(option);
            });
        } else {
            const option = document.createElement('option');
            option.value = 'One Size';
            option.textContent = 'One Size';
            sizeSelect.appendChild(option);
            sizeSelect.disabled = true;
        }

        const colorOptionsDiv = document.getElementById('color-options');
        colorOptionsDiv.innerHTML = '';
        if (currentProduct.colors?.length) {
            currentProduct.colors.forEach((color, index) => {
                const swatch = document.createElement('div');
                swatch.className = 'color-swatch';
                swatch.style.backgroundColor = color.hex;
                swatch.dataset.colorName = color.name;
                swatch.dataset.colorHex = color.hex;
                swatch.addEventListener('click', () => selectColor(color, swatch));
                colorOptionsDiv.appendChild(swatch);
                if (index === 0) {
                    selectColor(color, swatch);
                }
            });
        } else {
            const noColorMessage = document.createElement('span');
            noColorMessage.textContent = 'No color options';
            noColorMessage.style.color = '#bbb';
            colorOptionsDiv.appendChild(noColorMessage);
        }

        const dotsContainer = document.getElementById('slideshow-dots');
        dotsContainer.innerHTML = '';
        currentProduct.images.forEach((_, index) => {
            const dot = document.createElement('span');
            dot.className = 'dot';
            dot.addEventListener('click', () => currentSlide(index));
            dotsContainer.appendChild(dot);
        });
    } else {
        document.getElementById('product-name').textContent = 'Product Not Found';
        document.getElementById('product-price').textContent = '';
        document.getElementById('product-description').textContent = 'Please go to the Shop page to select a product.';
        document.getElementById('add-to-cart-btn').style.display = 'none';
        document.querySelector('.options-container').style.display = 'none';
        document.querySelector('.slideshow-container').innerHTML = '<p style="text-align:center; padding:20px;">No image available.</p>';
    }
}

function selectColor(color, swatchElement) {
    document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('selected'));
    swatchElement.classList.add('selected');
    showSlides(slideIndex);
}

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    if (!currentProduct || !currentProduct.images || currentProduct.images.length === 0) {
        document.getElementById('product-main-image').src = '../Images/fallback.jpg';
        return;
    }

    const images = currentProduct.images;
    const dots = document.querySelectorAll('.dot');
    const mainImage = document.getElementById('product-main-image');

    if (n >= images.length) { slideIndex = 0; }
    if (n < 0) { slideIndex = images.length - 1; }

    mainImage.src = images[slideIndex];
    mainImage.alt = `${currentProduct.name} - ${slideIndex + 1}`;

    dots.forEach(dot => dot.classList.remove('active'));
    if (dots[slideIndex]) {
        dots[slideIndex].classList.add('active');
    }
}

function displayFeedback(message, type = "info") {
    const feedbackElement = document.getElementById('feedback');
    if (feedbackElement) {
        feedbackElement.textContent = message;
        feedbackElement.style.color = type === "error" ? "red" : "#ffd700";
        feedbackElement.style.display = 'block';
        setTimeout(() => {
            feedbackElement.style.display = 'none';
            feedbackElement.textContent = '';
        }, 3000);
    }
}

window.addToCartWithAnimation = function (sourceElement, product) {
    if (flying) return;
    flying = true;

    const cartIcon = document.querySelector('.cart-icon-container i');
    const cartIconRect = cartIcon.getBoundingClientRect();
    const sourceRect = sourceElement.getBoundingClientRect();

    const dx = cartIconRect.left - sourceRect.left;
    const dy = cartIconRect.top - sourceRect.top;

    const dot = document.createElement('div');
    dot.className = 'flying-dot';
    dot.style.left = `${sourceRect.left + sourceRect.width / 2}px`;
    dot.style.top = `${sourceRect.top + sourceRect.height / 2}px`;
    dot.style.setProperty('--dx', `${dx}px`);
    dot.style.setProperty('--dy', `${dy}px`);
    document.body.appendChild(dot);

    dot.addEventListener('animationend', () => {
        dot.remove();
        flying = false;
        addToCart(product);
    });
};

function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingIndex = cart.findIndex(item =>
        item.id === product.id &&
        item.selectedSize === product.selectedSize &&
        item.selectedColor === product.selectedColor
    );

    if (existingIndex !== -1) {
        cart[existingIndex].quantity = (cart[existingIndex].quantity || 1) + 1;
    } else {
        product.quantity = 1;
        cart.push(product);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartUI();
}

function changeQuantity(id, delta) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    const item = cart.find(i => i.id === id);
    if (!item) return;

    item.quantity += delta;
    if (item.quantity <= 0) {
        cart = cart.filter(i => i.id !== id);
    }

    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartUI();
}

function removeItem(id) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(i => i.id !== id);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartUI();
}

function updateTotal() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
    const totalElement = document.getElementById("cart-total");
    if (totalElement) totalElement.textContent = `${total.toFixed(2)}`;
}

function updateCartUI() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    document.querySelectorAll('#cart-count-top').forEach(el => el.textContent = totalItems);

    const cartContainer = document.getElementById("cart-items");
    if (!cartContainer) return;

    cartContainer.innerHTML = "";

    if (cart.length === 0) {
        cartContainer.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }

    cart.forEach(item => {
        const div = document.createElement("div");
        div.className = "cart-item";
        div.setAttribute("data-id", item.id);
        div.innerHTML = `
            <img src="${item.images[0]}" alt="${item.name}" class="cart-item-image">
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p>Size: ${item.selectedSize}</p>
                <p>Color: ${item.selectedColor}</p>
                <div class="quantity-controls">
                    <button onclick="changeQuantity('${item.id}', -1)">−</button>
                    <span id="qty-${item.id}">${item.quantity}</span>
                    <button onclick="changeQuantity('${item.id}', 1)">+</button>
                </div>
                <p>Rs ${(item.price * item.quantity).toFixed(2)}</p>
                <button onclick="removeItem('${item.id}')" class="remove-btn">🗑️</button>
            </div>
        `;
        cartContainer.appendChild(div);
    });

    updateTotal();
}

function checkout() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    if (cart.length === 0) {
        alert("Your cart is empty. Please add items before proceeding to checkout.");
        return;
    }

    localStorage.setItem("cart", JSON.stringify(cart));

    // Delay ensures data is saved before navigation
    setTimeout(() => {
        window.location.href = "Check_Out.html";
    }, 100);
}
