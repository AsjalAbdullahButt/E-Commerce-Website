document.addEventListener("DOMContentLoaded", () => {
    // Show default section (profile) on load
    showSection('profile');
    loadUserProfile();
});

function showSection(sectionId) {
    // Hide all sections first
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });

    // Show the requested section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
    }

    // Update active menu item (optional)
    document.querySelectorAll('.menu li').forEach(item => {
        item.classList.remove('active-menu-item');
    });
    // Find the li that corresponds to the sectionId and add 'active-menu-item' class
    const correspondingMenuItem = document.querySelector(`.menu li[onclick*="showSection('${sectionId}')"]`);
    if (correspondingMenuItem) {
        correspondingMenuItem.classList.add('active-menu-item');
    }
}

function loadUserProfile() {
    const userProfile = JSON.parse(localStorage.getItem('userProfile'));
    const authArea = document.getElementById('auth-area');
    const profileInfo = document.getElementById('profile-info');
    const editProfileArea = document.getElementById('edit-profile-area');

    if (userProfile) {
        document.getElementById('user-name').textContent = userProfile.name || 'N/A';
        document.getElementById('user-address').textContent = userProfile.address || 'N/A';
        document.getElementById('user-phone').textContent = userProfile.phone || 'N/A';

        authArea.style.display = 'none';
        profileInfo.style.display = 'block';
        editProfileArea.style.display = 'none'; // Ensure edit area is hidden
    } else {
        authArea.style.display = 'block';
        profileInfo.style.display = 'none';
        editProfileArea.style.display = 'none';
    }
}

function login() {
    const nameInput = document.getElementById('username');
    const addressInput = document.getElementById('address');
    const phoneInput = document.getElementById('phone');

    const name = nameInput.value.trim();
    const address = addressInput.value.trim();
    const phone = phoneInput.value.trim();

    if (name && address && phone) {
        const userProfile = { name, address, phone };
        localStorage.setItem('userProfile', JSON.stringify(userProfile));
        alert('Login/Profile saved successfully!');
        loadUserProfile(); // Update UI
        // Clear input fields
        nameInput.value = '';
        addressInput.value = '';
        phoneInput.value = '';
    } else {
        alert('Please fill in all profile details.');
    }
}

function logout() {
    localStorage.removeItem('userProfile');
    alert('Logged out successfully!');
    loadUserProfile(); // Update UI
}

function googleLogin() {
    alert('Google Login functionality is not implemented yet. This is a placeholder.');
    // In a real application, you would integrate with Google's OAuth API here.
}

function showEditProfile() {
    const userProfile = JSON.parse(localStorage.getItem('userProfile'));
    if (userProfile) {
        document.getElementById('edit-username').value = userProfile.name || '';
        document.getElementById('edit-address').value = userProfile.address || '';
        document.getElementById('edit-phone').value = userProfile.phone || '';

        document.getElementById('profile-info').style.display = 'none';
        document.getElementById('edit-profile-area').style.display = 'block';
    }
}

function saveProfile() {
    const name = document.getElementById('edit-username').value.trim();
    const address = document.getElementById('edit-address').value.trim();
    const phone = document.getElementById('edit-phone').value.trim();

    if (name && address && phone) {
        const updatedProfile = { name, address, phone };
        localStorage.setItem('userProfile', JSON.stringify(updatedProfile));
        alert('Profile updated successfully!');
        loadUserProfile();
    } else {
        alert('Please fill in all fields to save your profile.');
    }
}

function cancelEditProfile() {
    loadUserProfile(); // Revert to displaying current profile info
}
